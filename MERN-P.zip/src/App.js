
import './App.css';
// import MyNavbar from './components/MyNavbar.jsx';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from './pages/Home.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import Footer from './components/Footer';
import Navbar1 from './components/Navbar1.jsx';
import HeroSection from './components/HeroSection.jsx';
import Signup from './pages/Signup.jsx';

function App() {
  return (
    <Router>
      <Navbar1/>
      <div className="main-content">  {/* Added a wrapper to prevent overlap */}
        <HeroSection/>
        {/* <MyNavbar/> */}
        
      <Routes>
     {/* <Route path="/" element={<Home />} />  */}
        <Route path='/home' element={<Home/>}/>
        <Route path='/signup' element={<Signup/>}/>
        {/* <Route path='/' element={<About/>}/> */}
      </Routes>
      <Footer/>
      </div>
    </Router>
  );
}

export default App;
