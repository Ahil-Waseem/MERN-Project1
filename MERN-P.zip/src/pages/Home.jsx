import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import "../styles/Home.css";

export default function Home() {
  // ✅ Cards Data with Images
  const cardsData = [
    { id: 1, title: "Card 1", image: "/images/img1.png" },
    { id: 2, title: "Card 2", image: "/images/img2.png" },
    { id: 3, title: "Card 3", image: "/images/img3.png" },
    { id: 4, title: "Card 4", image: "/images/img4.png" },
    { id: 5, title: "Card 5", image: "/images/img5.png" },
    { id: 6, title: "Card 6", image: "/images/img6.png" },
    { id: 7, title: "Card 7", image: "/images/img7.png" },
    { id: 8, title: "Card 8", image: "/images/img8.png" },
  ];

  // ✅ Har card ke liye alag state
  const [cardStates, setCardStates] = useState(
    cardsData.reduce((acc, card) => {
      acc[card.id] = { selectedNumber: 1, selectedSize: "Half" };
      return acc;
    }, {})
  );

  // ✅ Dropdown change handle karne ka function
  const handleDropdownChange = (cardId, field, value) => {
    setCardStates((prevState) => ({
      ...prevState,
      [cardId]: {
        ...prevState[cardId],
        [field]: value,
      },
    }));
  };

  return (
    <div className="card-container">
      {cardsData.map((card) => (
        <Card key={card.id} style={{ width: "18rem", margin: "10px" }}>
          {/* ✅ Different Image for Each Card */}
          <Card.Img variant="top" src={card.image} alt={card.title} />

          <Card.Body>
            <Card.Title>{card.title}</Card.Title>
            <Card.Text>
              Some quick example text to build the bulk of the card's content.
            </Card.Text>

            {/* 🔹 Flexbox Container for Dropdowns and Button */}
            <div className="dropdown-container">
              {/* 🔹 Number Dropdown (1 to 6) */}
              <Form.Group className="dropdown-wrapper">
                <Form.Select
                  className="small-dropdown"
                  value={cardStates[card.id].selectedNumber}
                  onChange={(e) =>
                    handleDropdownChange(card.id, "selectedNumber", e.target.value)
                  }
                >
                  {[1, 2, 3, 4, 5, 6].map((num) => (
                    <option key={num} value={num}>
                      {num}
                    </option>
                  ))}
                </Form.Select>
              </Form.Group>

              {/* 🔹 Size Dropdown (Half / Full) */}
              <Form.Group className="dropdown-wrapper">
                <Form.Select
                  className="small-dropdown"
                  value={cardStates[card.id].selectedSize}
                  onChange={(e) =>
                    handleDropdownChange(card.id, "selectedSize", e.target.value)
                  }
                >
                  <option value="Half">Half</option>
                  <option value="Full">Full</option>
                </Form.Select>
              </Form.Group>

              <Button variant="primary" className="small-btn">
                Buy Now
              </Button>
            </div>
          </Card.Body>
        </Card>
      ))}
    </div>
  );
}
