const express = require('express');
const connectDB = require("./db");
const cors = require('cors'); // ✅ Step 1: Import cors

const app = express();
const port = 5000;

// ✅ Step 2: Add cors middleware BEFORE routes
app.use(cors({
  origin: 'http://localhost:3000', // your React frontend origin
  methods: ['GET', 'POST'],
  credentials: true
}));

connectDB()
  .then(() => {
    console.log("✅ Database Connected, Starting Server...");

    app.use(express.json()); // Middleware to parse JSON

    app.use('/api', require("./Routes/CreateUser")); // API routes

    app.listen(port, () => {
      console.log(`✅ Server running on http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error("❌ Error Connecting to Database:", err);
  });

// Optional root route
app.get('/', (req, res) => {
  res.send('Hello World!');
});
