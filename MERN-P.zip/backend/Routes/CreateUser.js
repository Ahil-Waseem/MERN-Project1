const express = require('express')
const router = express.Router()
const User = require('../models/User')
const {body, validationResult} = require('express-validator');


router.post("/createuser",[
    
    body('email').isEmail(),
    body('name').isLength({min: 5}),
    body('password','Incorrect Password').isLength({min: 5})],

    async (req, res)=>{

        const errors = validationResult(req);
        if(!errors.isEmpty()){
            return res.status(400).json({ errors: errors.array() });
        }
    try{
        await User.create({
            name: "Ahil Waseem",
            password: "123456",
            email: "ahil@gmial.com",
            location: "Mumbai"
        })
        res.json({success: true});
    }catch(error){
        console.log(error)
        res.json({success: false});
    }
})
module.exports = router;
// to check requrest and insert user in database using (inthunder client) extension and this will create/ add the user in your database using CreateUser.js router
//   in post method     localhost:5000/api/createuser

// for checking Validation in (thunder Client )
// post url = localhost:5000/api/createuser